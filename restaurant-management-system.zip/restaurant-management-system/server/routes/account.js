'use strict';
const { HttpError, Validator } = require('../lib/validate');
const { hashPassword, verifyPassword, DUMMY_HASH, checkPasswordStrength, createSession, destroySession, sessionCookie, createLimiter } = require('../lib/auth');
const { changeStatus, getOrderDetail } = require('../services/orders');
const { updateReservation } = require('../services/reservations');

const pub = (u) => ({ id: u.id, name: u.name, email: u.email, phone: u.phone, role: u.role });

function register(r, { db, cfg }) {
  const loginLimiter = createLimiter(8, 10 * 60 * 1000);
  const signupLimiter = createLimiter(10, 60 * 60 * 1000);
  const cookieOpts = { maxAgeSec: cfg.sessionDays * 86400, secure: cfg.secureCookies };

  r.post('/api/auth/register', 'none', (ctx) => {
    if (!signupLimiter.take(ctx.ip)) throw new HttpError(429, 'Too many sign-ups from this connection.');
    const v = new Validator(ctx.body);
    const name = v.str('name', { min: 2, max: 80, label: 'Name' });
    const email = v.email('email');
    const phone = v.phone('phone');
    v.done();
    checkPasswordStrength(ctx.body.password);
    if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) throw new HttpError(409, 'An account with this email already exists.', { email: 'Already registered' });
    // Role is always "customer" here; admins are created only via the seed script.
    const info = db.prepare("INSERT INTO users (name, email, phone, password_hash, role) VALUES (?,?,?,?, 'customer')").run(name, email, phone, hashPassword(ctx.body.password));
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(Number(info.lastInsertRowid));
    ctx.headers['Set-Cookie'] = sessionCookie(createSession(db, user.id, cfg.sessionDays), cookieOpts);
    ctx.status = 201;
    return { user: pub(user) };
  });

  r.post('/api/auth/login', 'none', (ctx) => {
    const email = String(ctx.body.email || '').trim().toLowerCase().slice(0, 120);
    const password = typeof ctx.body.password === 'string' ? ctx.body.password.slice(0, 200) : '';
    const key = ctx.ip + '|' + email;
    if (!loginLimiter.take(key)) throw new HttpError(429, 'Too many failed attempts. Please wait 10 minutes and try again.');
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    const ok = verifyPassword(password, user ? user.password_hash : DUMMY_HASH);
    if (!user || !ok) throw new HttpError(401, 'Incorrect email or password.');
    loginLimiter.reset(key);
    db.prepare("DELETE FROM sessions WHERE expires_at <= datetime('now')").run();
    ctx.headers['Set-Cookie'] = sessionCookie(createSession(db, user.id, cfg.sessionDays), cookieOpts);
    return { user: pub(user) };
  });

  r.post('/api/auth/logout', 'none', (ctx) => {
    destroySession(db, ctx.token);
    ctx.headers['Set-Cookie'] = sessionCookie('', { ...cookieOpts, maxAgeSec: 0 });
    return null;
  });

  r.get('/api/auth/me', 'none', (ctx) => ({ user: ctx.user ? pub(ctx.user) : null }));

  r.put('/api/account/profile', 'user', (ctx) => {
    const v = new Validator(ctx.body);
    const name = v.str('name', { min: 2, max: 80, label: 'Name' });
    const phone = v.phone('phone');
    v.done();
    db.prepare("UPDATE users SET name = ?, phone = ?, updated_at = datetime('now') WHERE id = ?").run(name, phone, ctx.user.id);
    return { user: pub(db.prepare('SELECT * FROM users WHERE id = ?').get(ctx.user.id)) };
  });

  r.post('/api/account/password', 'user', (ctx) => {
    const row = db.prepare('SELECT * FROM users WHERE id = ?').get(ctx.user.id);
    if (typeof ctx.body.current !== 'string' || !verifyPassword(ctx.body.current, row.password_hash)) throw new HttpError(403, 'Current password is incorrect.', { current: 'Incorrect password' });
    checkPasswordStrength(ctx.body.password);
    db.prepare("UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?").run(hashPassword(ctx.body.password), ctx.user.id);
    // Sign out other devices.
    db.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?').run(ctx.user.id, require('crypto').createHash('sha256').update(ctx.token).digest('hex'));
    return null;
  });

  r.get('/api/account/orders', 'user', (ctx) => {
    const rows = db.prepare('SELECT id FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 100').all(ctx.user.id);
    return rows.map((x) => { const o = getOrderDetail(db, x.id); delete o.next_statuses; return o; });
  });

  r.post('/api/account/orders/:id/cancel', 'user', (ctx) => {
    const o = db.prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?').get(Number(ctx.params.id), ctx.user.id);
    if (!o) throw new HttpError(404, 'Order not found');
    if (o.status !== 'pending') throw new HttpError(409, 'Only orders that are still pending can be cancelled. Please call the restaurant.');
    return changeStatus(db, o.id, 'cancelled', 'Cancelled by customer');
  });

  r.get('/api/account/reservations', 'user', (ctx) =>
    db.prepare('SELECT * FROM reservations WHERE user_id = ? ORDER BY res_date DESC, res_time DESC LIMIT 100').all(ctx.user.id));

  r.post('/api/account/reservations/:id/cancel', 'user', (ctx) => {
    const row = db.prepare('SELECT * FROM reservations WHERE id = ? AND user_id = ?').get(Number(ctx.params.id), ctx.user.id);
    if (!row) throw new HttpError(404, 'Reservation not found');
    if (!['pending', 'approved'].includes(row.status)) throw new HttpError(409, `A ${row.status} reservation cannot be cancelled.`);
    return updateReservation(db, row.id, { status: 'cancelled' });
  });
}

module.exports = { register };
