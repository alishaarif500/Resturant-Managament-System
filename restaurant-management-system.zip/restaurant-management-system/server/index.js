'use strict';
const fs = require('fs');
const http = require('http');
const path = require('path');
const { load } = require('./config');
const { openDatabase } = require('./lib/db');
const { Router } = require('./lib/router');
const { sendJson } = require('./lib/http');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8',
};

const SECURITY_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data: https:; script-src 'self'; style-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Permissions-Policy': 'geolocation=(), camera=(), microphone=()',
};

function createApp(overrides = {}) {
  const cfg = load(overrides);
  const db = openDatabase(cfg.dbPath);
  const router = new Router(db, cfg);
  for (const name of ['public', 'account', 'admin']) require(`./routes/${name}`).register(router, { db, cfg });

  function serveStatic(req, res, url) {
    if (!['GET', 'HEAD'].includes(req.method)) return sendJson(res, 405, { ok: false, error: { message: 'Method not allowed' } });
    let rel; try { rel = decodeURIComponent(url.pathname); } catch { return sendJson(res, 400, { ok: false, error: { message: 'Bad request' } }); }
    const isUpload = rel.startsWith('/uploads/');
    const base = isUpload ? cfg.uploadDir : cfg.publicDir;
    let file = path.normalize(path.join(base, isUpload ? rel.slice('/uploads/'.length) : rel));
    if (!file.startsWith(base + path.sep) && file !== base) return sendJson(res, 403, { ok: false, error: { message: 'Forbidden' } });
    if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
    const ext = path.extname(file).toLowerCase();
    if (isUpload && ext === '.svg') { return sendJson(res, 404, { ok: false, error: { message: 'Not found' } }); }
    if (!fs.existsSync(file)) {
      if (ext && ext !== '.html') return sendJson(res, 404, { ok: false, error: { message: 'Not found' } });
      file = path.join(cfg.publicDir, 'index.html'); // single-page app entry
    }
    const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
    const stat = fs.statSync(file);
    res.writeHead(200, { 'Content-Type': type, 'Content-Length': stat.size, 'Cache-Control': isUpload ? 'public, max-age=86400' : 'no-cache' });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  }

  const server = http.createServer((req, res) => {
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
    if (cfg.secureCookies) res.setHeader('Strict-Transport-Security', 'max-age=15552000');
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) return router.handle(req, res, url);
    return serveStatic(req, res, url);
  });
  server.requestTimeout = 30000;

  return { server, db, cfg, close: () => new Promise((resolve) => { server.close(() => { db.close(); resolve(); }); server.closeAllConnections && server.closeAllConnections(); }) };
}

module.exports = { createApp };

if (require.main === module) {
  const app = createApp();
  app.server.listen(app.cfg.port, () => console.log(`Restaurant Management System running at http://localhost:${app.cfg.port}`));
  const stop = () => app.close().then(() => process.exit(0));
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
}
