'use strict';
const { HttpError, Validator, digitsOnly } = require('../lib/validate');
const { getSettings } = require('../lib/db');
const { createLimiter } = require('../lib/auth');
const { quote } = require('../services/pricing');
const { createOrder, getOrderDetail } = require('../services/orders');
const { createReservation } = require('../services/reservations');

const FOOD_SELECT = `SELECT f.id, f.category_id, f.name, f.description, f.price_cents, f.image_url, f.available, f.featured, f.popular,
  c.name AS category_name, c.slug AS category_slug,
  (SELECT COUNT(*) FROM food_variations v WHERE v.food_id = f.id) + (SELECT COUNT(*) FROM food_extras e WHERE e.food_id = f.id) AS option_count
  FROM food_items f JOIN categories c ON c.id = f.category_id`;

function register(r, { db }) {
  const trackLimiter = createLimiter(20, 10 * 60 * 1000);
  const orderLimiter = createLimiter(30, 10 * 60 * 1000);
  const contactLimiter = createLimiter(10, 10 * 60 * 1000);

  r.get('/api/health', 'none', () => ({ status: 'ok' }));
  r.get('/api/settings', 'none', () => getSettings(db));

  r.get('/api/categories', 'none', () => db.prepare(
    `SELECT c.id, c.name, c.slug, c.description,
       (SELECT COUNT(*) FROM food_items f WHERE f.category_id = c.id AND f.available = 1) AS item_count
     FROM categories c WHERE c.active = 1 ORDER BY c.sort_order, c.name`).all());

  r.get('/api/foods', 'none', ({ query }) => {
    const where = ['c.active = 1']; const args = [];
    if (query.category) { where.push('c.slug = ?'); args.push(query.category); }
    if (query.featured === '1') where.push('f.featured = 1');
    if (query.popular === '1') where.push('f.popular = 1');
    if (query.q) {
      const like = '%' + String(query.q).slice(0, 60).replace(/[\\%_]/g, (m) => '\\' + m) + '%';
      where.push("(f.name LIKE ? ESCAPE '\\' OR f.description LIKE ? ESCAPE '\\')"); args.push(like, like);
    }
    const order = {
      price_asc: 'f.price_cents ASC, f.name', price_desc: 'f.price_cents DESC, f.name', name: 'f.name COLLATE NOCASE',
    }[query.sort] || 'f.featured DESC, f.popular DESC, f.name COLLATE NOCASE';
    return db.prepare(`${FOOD_SELECT} WHERE ${where.join(' AND ')} ORDER BY ${order}`).all(...args);
  });

  r.get('/api/foods/:id', 'none', ({ params }) => {
    const food = db.prepare(`${FOOD_SELECT} WHERE f.id = ? AND c.active = 1`).get(Number(params.id));
    if (!food) throw new HttpError(404, 'Food item not found');
    food.variations = db.prepare('SELECT id, name, price_delta_cents FROM food_variations WHERE food_id = ? ORDER BY sort_order, id').all(food.id);
    food.extras = db.prepare('SELECT id, name, price_cents FROM food_extras WHERE food_id = ? ORDER BY id').all(food.id);
    return food;
  });

  r.get('/api/home', 'none', () => ({
    settings: getSettings(db),
    featured: db.prepare(`${FOOD_SELECT} WHERE f.featured = 1 AND f.available = 1 AND c.active = 1 ORDER BY f.name LIMIT 8`).all(),
    popular: db.prepare(`${FOOD_SELECT} WHERE f.popular = 1 AND f.available = 1 AND c.active = 1 ORDER BY f.name LIMIT 8`).all(),
    categories: db.prepare('SELECT id, name, slug, description FROM categories WHERE active = 1 ORDER BY sort_order, name').all(),
    promotions: db.prepare('SELECT id, title, description, code FROM promotions WHERE active = 1 ORDER BY id DESC').all(),
    testimonials: db.prepare('SELECT id, name, text, rating FROM testimonials WHERE active = 1 ORDER BY id DESC LIMIT 6').all(),
  }));

  // Server-side pricing preview used by the cart and checkout pages.
  r.post('/api/cart/quote', 'none', ({ body }) => {
    const q = quote(db, body);
    return {
      lines: q.lines, subtotal: q.subtotal, delivery: q.delivery, discount: q.discount, discountCode: q.discountCode,
      discountError: q.discountError, total: q.total, orderType: q.orderType, minOrder: q.minOrder, belowMinimum: q.belowMinimum,
    };
  });

  r.post('/api/orders', 'optional', (ctx) => {
    if (!orderLimiter.take(ctx.ip)) throw new HttpError(429, 'Too many orders from this connection. Please try again later.');
    const order = createOrder(db, ctx.body, ctx.user);
    ctx.status = 201;
    return order;
  });

  // Guests prove ownership with order number + the phone number used for the order.
  r.post('/api/orders/track', 'optional', (ctx) => {
    if (!trackLimiter.take(ctx.ip)) throw new HttpError(429, 'Too many attempts. Please wait a few minutes.');
    const v = new Validator(ctx.body);
    const number = v.str('orderNumber', { min: 1, max: 40, label: 'Order number' }).toUpperCase();
    const phone = v.str('phone', { min: 1, max: 25, label: 'Phone number' });
    v.done();
    const row = db.prepare('SELECT id, phone, user_id FROM orders WHERE order_number = ?').get(number);
    const owner = row && ctx.user && row.user_id === ctx.user.id;
    if (!row || (digitsOnly(row.phone) !== digitsOnly(phone) && !owner)) throw new HttpError(404, 'No order matches those details.');
    const o = getOrderDetail(db, row.id);
    delete o.next_statuses; delete o.user_id;
    return o;
  });

  r.post('/api/reservations', 'optional', (ctx) => {
    if (!orderLimiter.take('res' + ctx.ip)) throw new HttpError(429, 'Too many requests. Please try again later.');
    const res = createReservation(db, ctx.body, ctx.user);
    ctx.status = 201;
    return res;
  });

  r.post('/api/reservations/lookup', 'none', (ctx) => {
    if (!trackLimiter.take('rl' + ctx.ip)) throw new HttpError(429, 'Too many attempts. Please wait a few minutes.');
    const v = new Validator(ctx.body);
    const ref = v.str('ref', { min: 1, max: 20, label: 'Reference' }).toUpperCase();
    const phone = v.str('phone', { min: 1, max: 25, label: 'Phone number' });
    v.done();
    const row = db.prepare('SELECT * FROM reservations WHERE ref = ?').get(ref);
    if (!row || digitsOnly(row.phone) !== digitsOnly(phone)) throw new HttpError(404, 'No reservation matches those details.');
    return row;
  });

  r.post('/api/contact', 'none', (ctx) => {
    if (!contactLimiter.take(ctx.ip)) throw new HttpError(429, 'Too many messages. Please try again later.');
    const v = new Validator(ctx.body);
    const name = v.str('name', { min: 2, max: 80, label: 'Name' });
    const email = v.email('email');
    const phone = v.phone('phone', { required: false });
    const subject = v.str('subject', { max: 120, label: 'Subject' });
    const message = v.str('message', { min: 5, max: 2000, label: 'Message', multiline: true });
    v.done();
    db.prepare('INSERT INTO contact_messages (name, email, phone, subject, message) VALUES (?,?,?,?,?)').run(name, email, phone, subject, message);
    ctx.status = 201;
    return { received: true };
  });
}

module.exports = { register };
