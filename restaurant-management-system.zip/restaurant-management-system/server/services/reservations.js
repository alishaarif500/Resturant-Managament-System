'use strict';
const crypto = require('crypto');
const { HttpError, Validator } = require('../lib/validate');
const { tx, getSettings } = require('../lib/db');

const toMin = (t) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5));

/** Tables (capacity >= guests) that are free for the slot. Pending and approved reservations both hold a table. */
function freeTables(db, { date, time, guests, ignoreId = 0 }) {
  const S = getSettings(db);
  const dur = Number(S.reservation_duration_min) || 90;
  const tables = db.prepare('SELECT * FROM dining_tables WHERE active = 1 AND capacity >= ? ORDER BY capacity, id').all(guests);
  const busy = db.prepare(
    "SELECT table_id, res_time FROM reservations WHERE res_date = ? AND status IN ('pending','approved') AND table_id IS NOT NULL AND id != ?"
  ).all(date, ignoreId);
  return tables.filter((t) => !busy.some((b) => b.table_id === t.id && Math.abs(toMin(b.res_time) - toMin(time)) < dur));
}

function createReservation(db, body, user) {
  const v = new Validator(body);
  const name = v.str('name', { min: 2, max: 80, label: 'Name' });
  const phone = v.phone('phone');
  const email = v.email('email');
  const date = v.date('date', { label: 'Reservation date' });
  const time = v.time('time', { label: 'Reservation time' });
  const guests = v.int('guests', { min: 1, max: 50, label: 'Guests' });
  const requests = v.str('requests', { max: 300, label: 'Special requests', multiline: true });
  v.done();

  const S = getSettings(db);
  const today = new Date().toISOString().slice(0, 10);
  const nowMin = new Date().getUTCHours() * 60 + new Date().getUTCMinutes();
  if (date < today || (date === today && toMin(time) <= nowMin)) throw new HttpError(422, 'Please choose a future date and time.', { date: 'Must be in the future' });
  if (toMin(time) < toMin(S.reservation_open || '00:00') || toMin(time) > toMin(S.reservation_close || '23:59')) {
    throw new HttpError(422, `Reservations are available between ${S.reservation_open} and ${S.reservation_close}.`, { time: 'Outside reservation hours' });
  }

  return tx(db, () => {
    const free = freeTables(db, { date, time, guests });
    if (!free.length) throw new HttpError(409, 'Sorry, no table is available for that time and party size. Please try another time.');
    const ref = 'RES-' + crypto.randomBytes(3).toString('hex').toUpperCase();
    const info = db.prepare(
      `INSERT INTO reservations (ref, user_id, name, phone, email, res_date, res_time, guests, table_id, requests)
       VALUES (?,?,?,?,?,?,?,?,?,?)`
    ).run(ref, user ? user.id : null, name, phone, email, date, time, guests, free[0].id, requests);
    return db.prepare('SELECT * FROM reservations WHERE id = ?').get(Number(info.lastInsertRowid));
  });
}

const NEXT = {
  pending: ['approved', 'rejected', 'cancelled'],
  approved: ['completed', 'cancelled'],
  rejected: [], cancelled: [], completed: [],
};

function updateReservation(db, id, { status, tableId }) {
  return tx(db, () => {
    const r = db.prepare('SELECT * FROM reservations WHERE id = ?').get(id);
    if (!r) throw new HttpError(404, 'Reservation not found');
    let table = r.table_id;
    if (tableId !== undefined && tableId !== null) {
      const t = db.prepare('SELECT * FROM dining_tables WHERE id = ? AND active = 1').get(tableId);
      if (!t) throw new HttpError(422, 'Table not found');
      if (t.capacity < r.guests) throw new HttpError(409, `${t.name} seats ${t.capacity}, but the party is ${r.guests}.`);
      table = t.id;
    }
    const next = status || r.status;
    if (status && status !== r.status && !NEXT[r.status].includes(status)) throw new HttpError(409, `A ${r.status} reservation cannot become ${status}.`);
    if (['pending', 'approved'].includes(next)) {
      const free = freeTables(db, { date: r.res_date, time: r.res_time, guests: r.guests, ignoreId: r.id });
      if (!table || !free.some((t) => t.id === table)) throw new HttpError(409, 'That table is already reserved for an overlapping time.');
    }
    db.prepare("UPDATE reservations SET status = ?, table_id = ?, updated_at = datetime('now') WHERE id = ?").run(next, table, id);
    return db.prepare('SELECT * FROM reservations WHERE id = ?').get(id);
  });
}

module.exports = { createReservation, updateReservation, freeTables };
