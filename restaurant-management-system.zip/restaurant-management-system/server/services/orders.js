'use strict';
const crypto = require('crypto');
const { HttpError, Validator } = require('../lib/validate');
const { tx, getSettings } = require('../lib/db');
const { quote, fmt } = require('./pricing');

const STATUSES = ['pending', 'confirmed', 'preparing', 'ready', 'out_for_delivery', 'delivered', 'cancelled'];

function nextStatuses(order) {
  const t = order.order_type;
  switch (order.status) {
    case 'pending': return ['confirmed', 'cancelled'];
    case 'confirmed': return ['preparing', 'cancelled'];
    case 'preparing': return [t === 'pickup' ? 'ready' : 'out_for_delivery', 'cancelled'];
    case 'ready': return ['delivered', 'cancelled'];
    case 'out_for_delivery': return ['delivered', 'cancelled'];
    default: return [];
  }
}

function newOrderNumber(db) {
  const d = new Date().toISOString().slice(2, 10).replace(/-/g, '');
  for (let i = 0; i < 20; i++) {
    const rand = crypto.randomBytes(3).toString('hex').toUpperCase().slice(0, 5);
    const n = `ORD-${d}-${rand}`;
    if (!db.prepare('SELECT 1 FROM orders WHERE order_number = ?').get(n)) return n;
  }
  throw new Error('Could not allocate order number');
}

function createOrder(db, body, user) {
  const v = new Validator(body);
  const customer_name = v.str('name', { min: 2, max: 80, label: 'Name' });
  const phone = v.phone('phone');
  const email = v.email('email');
  const order_type = v.oneOf('orderType', ['delivery', 'pickup']);
  const payment = v.oneOf('paymentMethod', ['cod', 'online'], 'cod');
  const address = v.str('address', { max: 200, label: 'Address' });
  const city = v.str('city', { max: 80, label: 'City' });
  const notes = v.str('notes', { max: 300, label: 'Notes', multiline: true });
  if (order_type === 'delivery') {
    if (!address) v.fail('address', 'Delivery address is required');
    if (!city) v.fail('city', 'City is required');
  }
  if (payment === 'online') v.fail('paymentMethod', 'Online payment is not available yet. Please choose cash.');
  v.done();

  const S = getSettings(db);
  return tx(db, () => {
    const q = quote(db, { items: body.items, orderType: order_type, discountCode: body.discountCode });
    if (q.belowMinimum) throw new HttpError(422, `The minimum order is ${fmt(q.minOrder, S.currency_symbol || '$')}.`);
    if (body.discountCode && String(body.discountCode).trim() && q.discountError) throw new HttpError(422, q.discountError, { discountCode: q.discountError });

    const number = newOrderNumber(db);
    const info = db.prepare(
      `INSERT INTO orders (order_number, user_id, customer_name, phone, email, order_type, address, city, notes,
         payment_method, subtotal_cents, delivery_cents, discount_cents, discount_code, total_cents)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
    ).run(number, user ? user.id : null, customer_name, phone, email, order_type,
      order_type === 'delivery' ? address : '', order_type === 'delivery' ? city : '', notes,
      'cod', q.subtotal, q.delivery, q.discount, q.discountCode, q.total);
    const orderId = Number(info.lastInsertRowid);
    const ins = db.prepare(
      `INSERT INTO order_items (order_id, food_id, name, variation_name, extras, unit_price_cents, quantity, line_total_cents, instructions)
       VALUES (?,?,?,?,?,?,?,?,?)`
    );
    for (const l of q.lines) ins.run(orderId, l.foodId, l.name, l.variationName, JSON.stringify(l.extras), l.unitCents, l.quantity, l.lineCents, l.instructions);
    db.prepare('INSERT INTO order_events (order_id, status) VALUES (?, ?)').run(orderId, 'pending');
    return getOrderDetail(db, orderId);
  });
}

function getOrderDetail(db, id) {
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
  if (!order) return null;
  order.items = db.prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY id').all(id)
    .map((i) => ({ ...i, extras: safeJson(i.extras) }));
  order.events = db.prepare('SELECT status, created_at FROM order_events WHERE order_id = ? ORDER BY id').all(id);
  order.next_statuses = nextStatuses(order);
  return order;
}

function safeJson(s) { try { return JSON.parse(s); } catch { return []; } }

function changeStatus(db, id, status, reason = '') {
  return tx(db, () => {
    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
    if (!order) throw new HttpError(404, 'Order not found');
    if (!STATUSES.includes(status)) throw new HttpError(422, 'Unknown status');
    if (!nextStatuses(order).includes(status)) throw new HttpError(409, `An order that is "${order.status}" cannot move to "${status}".`);
    db.prepare("UPDATE orders SET status = ?, cancel_reason = ?, updated_at = datetime('now') WHERE id = ?")
      .run(status, status === 'cancelled' ? reason.slice(0, 200) : order.cancel_reason, id);
    db.prepare('INSERT INTO order_events (order_id, status) VALUES (?, ?)').run(id, status);
    return getOrderDetail(db, id);
  });
}

module.exports = { STATUSES, createOrder, getOrderDetail, changeStatus, nextStatuses };
