'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { HttpError, Validator, slugify } = require('../lib/validate');
const { tx, getSettings } = require('../lib/db');
const { STATUSES, getOrderDetail, changeStatus } = require('../services/orders');
const { updateReservation } = require('../services/reservations');

const SETTING_KEYS = {
  text: ['restaurant_name', 'tagline', 'hero_title', 'hero_subtitle', 'about_story', 'about_mission', 'about_vision', 'about_values',
    'quality_text', 'phone', 'whatsapp', 'email', 'address', 'map_url', 'opening_hours', 'facebook', 'instagram', 'twitter',
    'currency_symbol', 'reservation_open', 'reservation_close', 'why_choose'],
  int: ['delivery_fee_cents', 'free_delivery_over_cents', 'min_order_cents', 'reservation_duration_min'],
};

const MAGIC = [
  { ext: 'png', mime: 'image/png', test: (b) => b.length > 8 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  { ext: 'jpg', mime: 'image/jpeg', test: (b) => b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { ext: 'gif', mime: 'image/gif', test: (b) => b.length > 6 && ['GIF87a', 'GIF89a'].includes(b.subarray(0, 6).toString('latin1')) },
  { ext: 'webp', mime: 'image/webp', test: (b) => b.length > 12 && b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP' },
];

function register(r, { db, cfg }) {
  const A = 'admin';

  // ---------- Dashboard ----------
  r.get('/api/admin/stats', A, () => {
    const one = (sql, ...a) => db.prepare(sql).get(...a);
    const days = db.prepare(
      `SELECT date(created_at) AS day, COUNT(*) AS orders, COALESCE(SUM(total_cents),0) AS revenue
       FROM orders WHERE status != 'cancelled' AND date(created_at) >= date('now','-6 days') GROUP BY day`).all();
    const series = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      const f = days.find((x) => x.day === d);
      series.push({ day: d, orders: f ? f.orders : 0, revenue: f ? f.revenue : 0 });
    }
    return {
      totalOrders: one('SELECT COUNT(*) n FROM orders').n,
      pendingOrders: one("SELECT COUNT(*) n FROM orders WHERE status = 'pending'").n,
      completedOrders: one("SELECT COUNT(*) n FROM orders WHERE status = 'delivered'").n,
      cancelledOrders: one("SELECT COUNT(*) n FROM orders WHERE status = 'cancelled'").n,
      totalCustomers: one("SELECT COUNT(*) n FROM users WHERE role = 'customer'").n,
      menuItems: one('SELECT COUNT(*) n FROM food_items').n,
      totalReservations: one('SELECT COUNT(*) n FROM reservations').n,
      pendingReservations: one("SELECT COUNT(*) n FROM reservations WHERE status = 'pending'").n,
      unreadMessages: one('SELECT COUNT(*) n FROM contact_messages WHERE is_read = 0').n,
      revenueTotal: one("SELECT COALESCE(SUM(total_cents),0) n FROM orders WHERE status != 'cancelled'").n,
      revenueDelivered: one("SELECT COALESCE(SUM(total_cents),0) n FROM orders WHERE status = 'delivered'").n,
      revenueToday: one("SELECT COALESCE(SUM(total_cents),0) n FROM orders WHERE status != 'cancelled' AND date(created_at) = date('now')").n,
      last7Days: series,
      recentOrders: db.prepare('SELECT id, order_number, customer_name, total_cents, status, created_at FROM orders ORDER BY id DESC LIMIT 6').all(),
    };
  });

  // ---------- Categories ----------
  const catVals = (v) => ({
    name: v.str('name', { min: 2, max: 60, label: 'Name' }),
    description: v.str('description', { max: 200, label: 'Description' }),
    sort_order: v.int('sort_order', { min: 0, max: 9999, def: 0 }),
    active: v.bool('active', true),
  });
  r.get('/api/admin/categories', A, () => db.prepare(
    'SELECT c.*, (SELECT COUNT(*) FROM food_items f WHERE f.category_id = c.id) AS item_count FROM categories c ORDER BY sort_order, name').all());
  r.post('/api/admin/categories', A, (ctx) => {
    const v = new Validator(ctx.body); const c = catVals(v); v.done();
    const info = db.prepare('INSERT INTO categories (name, slug, description, sort_order, active) VALUES (?,?,?,?,?)')
      .run(c.name, slugify(c.name), c.description, c.sort_order, c.active);
    ctx.status = 201;
    return db.prepare('SELECT * FROM categories WHERE id = ?').get(Number(info.lastInsertRowid));
  });
  r.put('/api/admin/categories/:id', A, (ctx) => {
    const v = new Validator(ctx.body); const c = catVals(v); v.done();
    const id = Number(ctx.params.id);
    if (!db.prepare('SELECT 1 FROM categories WHERE id = ?').get(id)) throw new HttpError(404, 'Category not found');
    db.prepare("UPDATE categories SET name=?, slug=?, description=?, sort_order=?, active=?, updated_at=datetime('now') WHERE id=?")
      .run(c.name, slugify(c.name), c.description, c.sort_order, c.active, id);
    return db.prepare('SELECT * FROM categories WHERE id = ?').get(id);
  });
  r.del('/api/admin/categories/:id', A, (ctx) => {
    const id = Number(ctx.params.id);
    const n = db.prepare('SELECT COUNT(*) n FROM food_items WHERE category_id = ?').get(id).n;
    if (n) throw new HttpError(409, `This category still contains ${n} food item(s). Move or delete them first.`);
    if (!db.prepare('DELETE FROM categories WHERE id = ?').run(id).changes) throw new HttpError(404, 'Category not found');
    return null;
  });

  // ---------- Food ----------
  const foodList = () => db.prepare(
    `SELECT f.*, c.name AS category_name FROM food_items f JOIN categories c ON c.id = f.category_id ORDER BY f.id DESC`).all();
  const foodFull = (id) => {
    const f = db.prepare('SELECT f.*, c.name AS category_name FROM food_items f JOIN categories c ON c.id = f.category_id WHERE f.id = ?').get(id);
    if (!f) return null;
    f.variations = db.prepare('SELECT id, name, price_delta_cents FROM food_variations WHERE food_id = ? ORDER BY sort_order, id').all(id);
    f.extras = db.prepare('SELECT id, name, price_cents FROM food_extras WHERE food_id = ? ORDER BY id').all(id);
    return f;
  };
  function saveFood(db, id, body) {
    const v = new Validator(body);
    const f = {
      category_id: v.int('category_id', { min: 1, label: 'Category' }),
      name: v.str('name', { min: 2, max: 80, label: 'Name' }),
      description: v.str('description', { max: 500, label: 'Description', multiline: true }),
      price_cents: v.int('price_cents', { min: 0, max: 10000000, label: 'Price' }),
      image_url: v.imageUrl('image_url'),
      available: v.bool('available', true), featured: v.bool('featured'), popular: v.bool('popular'),
    };
    const variations = Array.isArray(body.variations) ? body.variations : [];
    const extras = Array.isArray(body.extras) ? body.extras : [];
    if (variations.length > 10) v.fail('variations', 'At most 10 sizes/options');
    if (extras.length > 20) v.fail('extras', 'At most 20 extras');
    const vars = variations.map((x) => { const w = new Validator(x); const o = { name: w.str('name', { min: 1, max: 40, label: 'Option name' }), delta: w.int('price_delta_cents', { min: -10000000, max: 10000000, def: 0 }) }; if (Object.keys(w.errors).length) v.fail('variations', Object.values(w.errors)[0]); return o; });
    const exs = extras.map((x) => { const w = new Validator(x); const o = { name: w.str('name', { min: 1, max: 40, label: 'Extra name' }), price: w.int('price_cents', { min: 0, max: 10000000, def: 0 }) }; if (Object.keys(w.errors).length) v.fail('extras', Object.values(w.errors)[0]); return o; });
    v.done();
    if (!db.prepare('SELECT 1 FROM categories WHERE id = ?').get(f.category_id)) throw new HttpError(422, 'Please correct the highlighted fields.', { category_id: 'Category does not exist' });
    return tx(db, () => {
      let fid = id;
      if (id) {
        if (!db.prepare('SELECT 1 FROM food_items WHERE id = ?').get(id)) throw new HttpError(404, 'Food item not found');
        db.prepare("UPDATE food_items SET category_id=?, name=?, description=?, price_cents=?, image_url=?, available=?, featured=?, popular=?, updated_at=datetime('now') WHERE id=?")
          .run(f.category_id, f.name, f.description, f.price_cents, f.image_url, f.available, f.featured, f.popular, id);
        db.prepare('DELETE FROM food_variations WHERE food_id = ?').run(id);
        db.prepare('DELETE FROM food_extras WHERE food_id = ?').run(id);
      } else {
        fid = Number(db.prepare('INSERT INTO food_items (category_id, name, description, price_cents, image_url, available, featured, popular) VALUES (?,?,?,?,?,?,?,?)')
          .run(f.category_id, f.name, f.description, f.price_cents, f.image_url, f.available, f.featured, f.popular).lastInsertRowid);
      }
      vars.forEach((o, i) => db.prepare('INSERT INTO food_variations (food_id, name, price_delta_cents, sort_order) VALUES (?,?,?,?)').run(fid, o.name, o.delta, i));
      exs.forEach((o) => db.prepare('INSERT INTO food_extras (food_id, name, price_cents) VALUES (?,?,?)').run(fid, o.name, o.price));
      return foodFull(fid);
    });
  }
  r.get('/api/admin/foods', A, () => foodList());
  r.get('/api/admin/foods/:id', A, (ctx) => foodFull(Number(ctx.params.id)) || (() => { throw new HttpError(404, 'Food item not found'); })());
  r.post('/api/admin/foods', A, (ctx) => { const f = saveFood(db, 0, ctx.body); ctx.status = 201; return f; });
  r.put('/api/admin/foods/:id', A, (ctx) => saveFood(db, Number(ctx.params.id), ctx.body));
  r.patch('/api/admin/foods/:id/flags', A, (ctx) => {
    const id = Number(ctx.params.id); const v = new Validator(ctx.body);
    const cur = db.prepare('SELECT * FROM food_items WHERE id = ?').get(id);
    if (!cur) throw new HttpError(404, 'Food item not found');
    const next = { available: 'available' in ctx.body ? v.bool('available') : cur.available, featured: 'featured' in ctx.body ? v.bool('featured') : cur.featured, popular: 'popular' in ctx.body ? v.bool('popular') : cur.popular };
    db.prepare("UPDATE food_items SET available=?, featured=?, popular=?, updated_at=datetime('now') WHERE id=?").run(next.available, next.featured, next.popular, id);
    return foodFull(id);
  });
  r.del('/api/admin/foods/:id', A, (ctx) => {
    // order_items keep their own name/price snapshot, so history is unaffected (food_id becomes NULL).
    if (!db.prepare('DELETE FROM food_items WHERE id = ?').run(Number(ctx.params.id)).changes) throw new HttpError(404, 'Food item not found');
    return null;
  });

  // ---------- Image upload (JSON data URL, validated by magic bytes) ----------
  r.post('/api/admin/upload', A, (ctx) => {
    const m = /^data:image\/(png|jpeg|gif|webp);base64,([A-Za-z0-9+/=]+)$/.exec(String(ctx.body.dataUrl || ''));
    if (!m) throw new HttpError(422, 'Please choose a PNG, JPEG, GIF or WebP image.');
    const buf = Buffer.from(m[2], 'base64');
    if (buf.length > cfg.maxUploadBytes) throw new HttpError(413, 'Image is too large (max 2 MB).');
    const kind = MAGIC.find((k) => k.test(buf));
    if (!kind) throw new HttpError(422, 'File content is not a valid image.');
    fs.mkdirSync(cfg.uploadDir, { recursive: true });
    const name = crypto.randomBytes(12).toString('hex') + '.' + kind.ext;
    fs.writeFileSync(path.join(cfg.uploadDir, name), buf);
    ctx.status = 201;
    return { url: '/uploads/' + name };
  });

  // ---------- Orders ----------
  r.get('/api/admin/orders', A, ({ query }) => {
    const where = []; const args = [];
    if (query.status && STATUSES.includes(query.status)) { where.push('status = ?'); args.push(query.status); }
    if (/^\d{4}-\d{2}-\d{2}$/.test(query.from || '')) { where.push('date(created_at) >= ?'); args.push(query.from); }
    if (/^\d{4}-\d{2}-\d{2}$/.test(query.to || '')) { where.push('date(created_at) <= ?'); args.push(query.to); }
    if (query.q) {
      const like = '%' + String(query.q).slice(0, 60).replace(/[\\%_]/g, (c) => '\\' + c) + '%';
      where.push("(order_number LIKE ? ESCAPE '\\' OR customer_name LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\')"); args.push(like, like, like, like);
    }
    const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const page = Math.max(1, parseInt(query.page, 10) || 1); const size = 20;
    const total = db.prepare(`SELECT COUNT(*) n FROM orders ${w}`).get(...args).n;
    const orders = db.prepare(`SELECT id, order_number, customer_name, phone, order_type, payment_method, total_cents, status, created_at FROM orders ${w} ORDER BY id DESC LIMIT ? OFFSET ?`).all(...args, size, (page - 1) * size);
    return { orders, total, page, pages: Math.max(1, Math.ceil(total / size)) };
  });
  r.get('/api/admin/orders/:id', A, (ctx) => getOrderDetail(db, Number(ctx.params.id)) || (() => { throw new HttpError(404, 'Order not found'); })());
  r.patch('/api/admin/orders/:id/status', A, (ctx) => {
    const v = new Validator(ctx.body);
    const status = v.oneOf('status', STATUSES);
    const reason = v.str('reason', { max: 200, label: 'Reason' });
    v.done();
    return changeStatus(db, Number(ctx.params.id), status, reason);
  });

  // ---------- Customers ----------
  r.get('/api/admin/customers', A, ({ query }) => {
    const like = '%' + String(query.q || '').slice(0, 60).replace(/[\\%_]/g, (c) => '\\' + c) + '%';
    return db.prepare(
      `SELECT u.id, u.name, u.email, u.phone, u.created_at,
         (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id) AS order_count,
         (SELECT COALESCE(SUM(total_cents),0) FROM orders o WHERE o.user_id = u.id AND o.status != 'cancelled') AS spent_cents
       FROM users u WHERE u.role = 'customer' AND (u.name LIKE ? ESCAPE '\\' OR u.email LIKE ? ESCAPE '\\' OR u.phone LIKE ? ESCAPE '\\')
       ORDER BY u.id DESC LIMIT 200`).all(like, like, like);
  });
  r.get('/api/admin/customers/:id', A, (ctx) => {
    const u = db.prepare("SELECT id, name, email, phone, created_at FROM users WHERE id = ? AND role = 'customer'").get(Number(ctx.params.id));
    if (!u) throw new HttpError(404, 'Customer not found');
    u.orders = db.prepare('SELECT id, order_number, total_cents, status, order_type, created_at FROM orders WHERE user_id = ? ORDER BY id DESC').all(u.id);
    u.reservations = db.prepare('SELECT id, ref, res_date, res_time, guests, status FROM reservations WHERE user_id = ? ORDER BY id DESC').all(u.id);
    return u;
  });

  // ---------- Reservations ----------
  r.get('/api/admin/reservations', A, ({ query }) => {
    const where = []; const args = [];
    if (['pending', 'approved', 'rejected', 'cancelled', 'completed'].includes(query.status)) { where.push('r.status = ?'); args.push(query.status); }
    if (/^\d{4}-\d{2}-\d{2}$/.test(query.date || '')) { where.push('r.res_date = ?'); args.push(query.date); }
    return db.prepare(
      `SELECT r.*, t.name AS table_name, t.capacity AS table_capacity FROM reservations r LEFT JOIN dining_tables t ON t.id = r.table_id
       ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY r.res_date DESC, r.res_time DESC LIMIT 300`).all(...args);
  });
  r.patch('/api/admin/reservations/:id', A, (ctx) => {
    const v = new Validator(ctx.body);
    const status = ctx.body.status === undefined ? undefined : v.oneOf('status', ['pending', 'approved', 'rejected', 'cancelled', 'completed']);
    const tableId = ctx.body.table_id === undefined ? undefined : v.int('table_id', { min: 1, label: 'Table' });
    v.done();
    return updateReservation(db, Number(ctx.params.id), { status, tableId });
  });

  // ---------- Reports ----------
  r.get('/api/admin/reports', A, ({ query }) => {
    const period = ['daily', 'weekly', 'monthly'].includes(query.period) ? query.period : 'daily';
    const cfgP = {
      daily: { fmt: '%Y-%m-%d', since: "date('now','-29 days')", label: 'Last 30 days' },
      weekly: { fmt: '%Y-W%W', since: "date('now','-83 days')", label: 'Last 12 weeks' },
      monthly: { fmt: '%Y-%m', since: "date('now','start of month','-11 months')", label: 'Last 12 months' },
    }[period];
    const rows = db.prepare(
      `SELECT strftime('${cfgP.fmt}', created_at) AS bucket, COUNT(*) AS orders, COALESCE(SUM(total_cents),0) AS revenue
       FROM orders WHERE status != 'cancelled' AND date(created_at) >= ${cfgP.since} GROUP BY bucket ORDER BY bucket`).all();
    const totals = db.prepare(
      `SELECT COUNT(*) AS orders, COALESCE(SUM(total_cents),0) AS revenue, COALESCE(AVG(total_cents),0) AS avg_order
       FROM orders WHERE status != 'cancelled' AND date(created_at) >= ${cfgP.since}`).get();
    const best = db.prepare(
      `SELECT oi.name, SUM(oi.quantity) AS quantity, SUM(oi.line_total_cents) AS revenue
       FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE o.status != 'cancelled'
       GROUP BY oi.name ORDER BY quantity DESC, revenue DESC LIMIT 10`).all();
    const byStatus = db.prepare('SELECT status, COUNT(*) AS n FROM orders GROUP BY status').all();
    return { period, label: cfgP.label, rows, totals: { ...totals, avg_order: Math.round(totals.avg_order) }, best, byStatus };
  });

  // ---------- Settings ----------
  r.get('/api/admin/settings', A, () => getSettings(db));
  r.put('/api/admin/settings', A, (ctx) => {
    const v = new Validator(ctx.body); const out = {};
    for (const k of SETTING_KEYS.text) if (k in ctx.body) out[k] = v.str(k, { max: k.startsWith('about_') || k === 'quality_text' || k === 'hero_subtitle' ? 1500 : 300, label: k, multiline: true });
    for (const k of SETTING_KEYS.int) if (k in ctx.body) out[k] = String(v.int(k, { min: 0, max: 100000000, label: k }));
    for (const k of ['reservation_open', 'reservation_close']) if (out[k] !== undefined && !/^([01]\d|2[0-3]):[0-5]\d$/.test(out[k])) v.fail(k, 'Use HH:MM');
    for (const k of ['facebook', 'instagram', 'twitter', 'map_url']) if (out[k] && !/^https:\/\/[^\s"'<>]+$/.test(out[k])) v.fail(k, 'Must be an https:// link');
    if (out.whatsapp && !/^\d{7,15}$/.test(out.whatsapp)) v.fail('whatsapp', 'Digits only, with country code (e.g. 15551234567)');
    if (out.restaurant_name !== undefined && !out.restaurant_name) v.fail('restaurant_name', 'Required');
    v.done();
    tx(db, () => { for (const [k, val] of Object.entries(out)) db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(k, val); });
    return getSettings(db);
  });

  // ---------- Small CRUD tables ----------
  function crud(base, table, spec) {
    r.get(base, A, () => db.prepare(`SELECT * FROM ${table} ORDER BY id DESC`).all());
    r.post(base, A, (ctx) => {
      const v = new Validator(ctx.body); const vals = spec(v); v.done();
      const cols = Object.keys(vals);
      const info = db.prepare(`INSERT INTO ${table} (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`).run(...Object.values(vals));
      ctx.status = 201;
      return db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(Number(info.lastInsertRowid));
    });
    r.put(`${base}/:id`, A, (ctx) => {
      const v = new Validator(ctx.body); const vals = spec(v); v.done();
      const id = Number(ctx.params.id);
      const res = db.prepare(`UPDATE ${table} SET ${Object.keys(vals).map((c) => c + ' = ?').join(',')} WHERE id = ?`).run(...Object.values(vals), id);
      if (!res.changes) throw new HttpError(404, 'Not found');
      return db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
    });
    r.del(`${base}/:id`, A, (ctx) => {
      if (!db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(Number(ctx.params.id)).changes) throw new HttpError(404, 'Not found');
      return null;
    });
  }
  crud('/api/admin/promotions', 'promotions', (v) => ({ title: v.str('title', { min: 2, max: 80, label: 'Title' }), description: v.str('description', { max: 300, label: 'Description' }), code: v.str('code', { max: 30, label: 'Code' }), active: v.bool('active', true) }));
  crud('/api/admin/testimonials', 'testimonials', (v) => ({ name: v.str('name', { min: 2, max: 60, label: 'Name' }), text: v.str('text', { min: 5, max: 400, label: 'Text', multiline: true }), rating: v.int('rating', { min: 1, max: 5, def: 5 }), active: v.bool('active', true) }));
  crud('/api/admin/discounts', 'discount_codes', (v) => {
    const o = { code: v.str('code', { min: 3, max: 30, label: 'Code' }).toUpperCase(), percent: v.int('percent', { min: 1, max: 100, label: 'Percent' }), min_subtotal_cents: v.int('min_subtotal_cents', { min: 0, max: 100000000, def: 0 }), active: v.bool('active', true) };
    const exp = v.str('expires_on', { max: 10, label: 'Expiry' });
    if (exp && !/^\d{4}-\d{2}-\d{2}$/.test(exp)) v.fail('expires_on', 'Use YYYY-MM-DD');
    o.expires_on = exp || null;
    if (o.code && !/^[A-Z0-9_-]+$/.test(o.code)) v.fail('code', 'Letters, numbers, - and _ only');
    return o;
  });
  crud('/api/admin/tables', 'dining_tables', (v) => ({ name: v.str('name', { min: 1, max: 30, label: 'Name' }), capacity: v.int('capacity', { min: 1, max: 50, label: 'Capacity' }), active: v.bool('active', true) }));

  // ---------- Contact messages ----------
  r.get('/api/admin/messages', A, () => db.prepare('SELECT * FROM contact_messages ORDER BY id DESC LIMIT 200').all());
  r.patch('/api/admin/messages/:id', A, (ctx) => {
    const v = new Validator(ctx.body); const read = v.bool('is_read', true);
    if (!db.prepare('UPDATE contact_messages SET is_read = ? WHERE id = ?').run(read, Number(ctx.params.id)).changes) throw new HttpError(404, 'Message not found');
    return null;
  });
  r.del('/api/admin/messages/:id', A, (ctx) => {
    if (!db.prepare('DELETE FROM contact_messages WHERE id = ?').run(Number(ctx.params.id)).changes) throw new HttpError(404, 'Message not found');
    return null;
  });
}

module.exports = { register };
