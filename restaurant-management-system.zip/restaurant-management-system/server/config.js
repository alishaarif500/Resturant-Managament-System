'use strict';
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');

// Minimal .env loader (no dependency). Real environment variables win.
(function loadEnv() {
  const file = path.join(root, '.env');
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
})();

const abs = (p, fallback) => path.resolve(root, p || fallback);

function load(overrides = {}) {
  return {
    root,
    port: Number(process.env.PORT) || 3000,
    dbPath: abs(process.env.DB_PATH, 'data/restaurant.db'),
    uploadDir: abs(process.env.UPLOAD_DIR, 'public/uploads'),
    publicDir: path.join(root, 'public'),
    secureCookies: process.env.COOKIE_SECURE === 'true' || process.env.NODE_ENV === 'production',
    // Set TRUST_PROXY=true only when running behind a reverse proxy you control (uses X-Forwarded-For for rate limiting).
    trustProxy: process.env.TRUST_PROXY === 'true',
    sessionDays: 7,
    maxJsonBytes: 3 * 1024 * 1024,
    maxUploadBytes: 2 * 1024 * 1024,
    ...overrides,
  };
}

module.exports = { load };
