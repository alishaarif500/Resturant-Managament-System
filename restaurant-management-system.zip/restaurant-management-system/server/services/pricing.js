'use strict';
const { HttpError } = require('../lib/validate');
const { getSettings } = require('../lib/db');

const toInt = (v) => (typeof v === 'string' && /^\d+$/.test(v) ? Number(v) : v);
const fmt = (cents, sym) => `${sym}${(cents / 100).toFixed(2)}`;

/**
 * Prices a cart from CURRENT database prices. Anything price-like sent by the browser is ignored.
 * Returns a full breakdown. Never throws for a bad discount code (reports discountError instead).
 */
function quote(db, { items, orderType, discountCode }) {
  const S = getSettings(db);
  if (!Array.isArray(items) || items.length < 1) throw new HttpError(422, 'Your cart is empty.');
  if (items.length > 50) throw new HttpError(422, 'Too many different items in one order.');

  const lines = [];
  for (const it of items) {
    const foodId = toInt(it && it.foodId);
    const qty = toInt(it && it.quantity);
    if (!Number.isInteger(foodId)) throw new HttpError(422, 'Invalid item in cart.');
    if (!Number.isInteger(qty) || qty < 1 || qty > 50) throw new HttpError(422, 'Quantity must be between 1 and 50.');

    const food = db.prepare(
      'SELECT f.*, c.active AS cat_active FROM food_items f JOIN categories c ON c.id = f.category_id WHERE f.id = ?'
    ).get(foodId);
    if (!food) throw new HttpError(422, 'An item in your cart no longer exists. Please review your cart.');
    if (!food.available || !food.cat_active) throw new HttpError(409, `${food.name} is currently unavailable. Please remove it from your cart.`);

    let unit = food.price_cents;
    let variationName = '';
    const variations = db.prepare('SELECT * FROM food_variations WHERE food_id = ? ORDER BY sort_order, id').all(food.id);
    if (variations.length) {
      const wanted = it.variationId !== undefined && it.variationId !== null && it.variationId !== '' ? toInt(it.variationId) : variations[0].id;
      const v = variations.find((x) => x.id === wanted);
      if (!v) throw new HttpError(422, `Invalid size/option for ${food.name}.`);
      unit += v.price_delta_cents; variationName = v.name;
    }

    const extraIds = Array.isArray(it.extraIds) ? [...new Set(it.extraIds.map(toInt))] : [];
    if (extraIds.length > 20) throw new HttpError(422, 'Too many extras selected.');
    const extras = [];
    for (const id of extraIds) {
      const e = db.prepare('SELECT * FROM food_extras WHERE id = ? AND food_id = ?').get(id, food.id);
      if (!e) throw new HttpError(422, `Invalid extra for ${food.name}.`);
      unit += e.price_cents; extras.push({ name: e.name, price_cents: e.price_cents });
    }

    let instructions = typeof it.instructions === 'string' ? it.instructions.replace(/[\u0000-\u001F\u007F]/g, ' ').trim() : '';
    if (instructions.length > 200) throw new HttpError(422, 'Special instructions must be at most 200 characters.');

    lines.push({
      foodId: food.id, name: food.name, variationName, extras, instructions,
      unitCents: unit, quantity: qty, lineCents: unit * qty,
    });
  }

  const subtotal = lines.reduce((s, l) => s + l.lineCents, 0);
  const type = orderType === 'pickup' ? 'pickup' : 'delivery';

  let delivery = 0;
  if (type === 'delivery') {
    delivery = Number(S.delivery_fee_cents) || 0;
    const freeOver = Number(S.free_delivery_over_cents) || 0;
    if (freeOver > 0 && subtotal >= freeOver) delivery = 0;
  }

  let discount = 0; let code = ''; let discountError = '';
  const raw = typeof discountCode === 'string' ? discountCode.trim() : '';
  if (raw) {
    const row = db.prepare('SELECT * FROM discount_codes WHERE code = ?').get(raw);
    const today = new Date().toISOString().slice(0, 10);
    if (!row || !row.active) discountError = 'This discount code is not valid.';
    else if (row.expires_on && row.expires_on < today) discountError = 'This discount code has expired.';
    else if (subtotal < row.min_subtotal_cents) discountError = `This code needs a minimum order of ${fmt(row.min_subtotal_cents, S.currency_symbol || '$')}.`;
    else { discount = Math.min(subtotal, Math.floor((subtotal * row.percent) / 100)); code = row.code; }
  }

  const minOrder = Number(S.min_order_cents) || 0;
  return {
    lines, subtotal, delivery, discount, discountCode: code, discountError,
    total: subtotal - discount + delivery,
    orderType: type, minOrder, belowMinimum: subtotal < minOrder,
  };
}

module.exports = { quote, fmt };
